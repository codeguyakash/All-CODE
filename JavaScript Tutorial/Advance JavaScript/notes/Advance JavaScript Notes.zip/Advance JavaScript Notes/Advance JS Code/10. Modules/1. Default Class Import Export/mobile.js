// Default Export Class
export default class Nokia {
  VolumnUp() {
    console.log("High Volumn");
  }
}

/*
 class Nokia {
  VolumnUp() {
    console.log("High Volumn");
  }
}
export default Nokia;

*/
