// Named Export Variable
export const a = 10;

/*
const a = 10;
export { a };
*/
