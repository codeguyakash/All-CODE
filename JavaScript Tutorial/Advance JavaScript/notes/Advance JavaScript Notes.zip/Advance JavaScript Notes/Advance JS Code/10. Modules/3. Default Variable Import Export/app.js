// Default Import Variable
import a from "./mobile.js";
console.log(a);
