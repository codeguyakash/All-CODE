// Default Import Function
import show from "./mobile.js";
show();
