// Default Export Function
export default function show() {
  console.log("Hello Module");
}

/*
function show() {
  console.log("Hello Module");
}
export default show;

*/
