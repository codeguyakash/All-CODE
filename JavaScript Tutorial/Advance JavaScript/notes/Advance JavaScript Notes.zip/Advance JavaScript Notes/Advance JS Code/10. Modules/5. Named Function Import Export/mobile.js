// Named Export Function
export function show() {
  console.log("Hello Module");
}

/*
function show() {
 console.log("Hello Module");
}
export {show};

*/
